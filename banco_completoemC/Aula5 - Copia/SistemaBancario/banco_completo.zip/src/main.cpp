#include <iostream>
#include "banco.h"
using namespace std;

int main()
{
    Banco b1;
    b1.atendimento();

    return 0;
}